﻿namespace NugetForUnity
{
    public enum RepositoryType
    {
        NotSpecified = 0,
        Git,
        TfsGit
    }
}
