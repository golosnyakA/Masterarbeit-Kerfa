## Description
[Describe the issue you have.]

- **NuGet Package:** [What is the name and version of the NuGet package you are installing?]
- **NuGetForUnity Version:** [What version of NuGetForUnity are you running?]
- **Unity Version:** [What version of Unity are you using?]
- **Operating System:** [What OS are you on?]
